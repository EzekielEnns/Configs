-- Config
require('settings')
require('plugins')
require('keys')
require('files')
require('cocsett')--require('cutils')
require('status')
require('dbAccess')

--[[ 
    TODO add 
        bn,bp,bd
        %bd|e# (this is to close all buffers but this one) 
        Buffers
]]-- 
